import pandas as pd
import numpy as np
from sklearn import linear_model
from sklearn import metrics
import plotly.graph_objs as go
import plotly.plotly as py
from plotly.graph_objs import *
from sklearn import decomposition
from sklearn.decomposition import PCA
py.sign_in('nguan' , 'noVwA7UNf8cGdlrlmaaS')
from sklearn.metrics import pairwise_distances
from sklearn.cluster import SpectralClustering
from sklearn.cluster import AffinityPropagation
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.cluster import MeanShift
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn import metrics

def scatter_with_color_dimension_graph(feature , target , layout_labels ) :
    '''Scatter with color dimension graph to visualize the density of the
    Given feature with target
    : param feature :
    : param target 
    : param layout labels :
    : return: '''

    trace1 = go.Scatter (
        y=feature,
        mode='markers',
        marker=dict(
                size=16,
                color=target,
                colorscale ='Viridis',
                showscale=True
        )
    )
    layout = go.Layout (
            title = layout_labels[2],
            xaxis=dict( title=layout_labels[0]) , yaxis=dict( title=layout_labels[ 1 ]))
    data = [ trace1 ]
    fig = Figure( data=data , layout=layout )
    #py.image.save_as( fig , filename=layout_labels[ 2 ] + '_Density.png' )
    print("plotting")
    
def main () :
#    colNames = ['ID', 'RI', 'Na', 'Mg', 'Al', 'Si', 'K', 'Ca', 'Ba', 'Fe', 'Type']
#    colNames1 = ['RI', 'Na', 'Mg', 'Al', 'Si', 'K', 'Ca', 'Ba', 'Fe']
#    glass_data = pd.read_csv('glass_data_labeled.csv')
#    #types = list(map(int, glass_data['Type'][1:]))
#    X = glass_data[['RI', 'Na', 'Mg', 'Al', 'Si', 'K', 'Ca', 'Ba', 'Fe']]
#    #for x in colNames1:
#    #print ("glass_data_",x,"::", list(glass_data[x][1:])  )
#    #print ("glass_data_target :: " , np.array( glass_data['Type'] ) )
#        #print("forloop")
#        #sample = " Sample " + x + " − Glass Type Density Graph "
#        #graph_labels = [ " Number of Observations " , " & Glass Type " , sample ]
#        #scatter_with_color_dimension_graph( list ( glass_data[x][1:] ),
#         #                                  np.array( types ) ,
#          #                                 graph_labels)
#        #np.corrcoef([glass_data['RI'],glass_data['Na'],glass_data['Mg'],glass_data['Al'],glass_data['Si'],glass_data['K'],glass_data['Ca'],glass_data['Ba'],glass_data['Fe']])
#    pca = PCA(.99)
#    pca.fit(X)
#    X = pca.transform(X)
#    print(pca.explained_variance_ratio_.cumsum()) 
#    
    
    clusters = [
    KMeans(n_clusters=6, random_state=1),
    AffinityPropagation(),
    SpectralClustering(n_clusters=6,
             assign_labels="discretize",
             random_state=1),
    MeanShift(bandwidth=15),
    GaussianMixture(n_components=6)
    ]

    names = ["K-Means", "Affinity Propagation", "Spectral Clustering","Mean Shift","Gaussian Mixture"]
    
    glass_data = pd.read_csv('glass_data_labeled.csv')
    X = glass_data[['RI', 'Na', 'Mg', 'Al', 'Si', 'K', 'Ca', 'Ba', 'Fe']]
    y = glass_data['Type']
    
    pca = decomposition.PCA(n_components=6)
    pca.fit(X)
    X = pca.transform(X)
    
    for name, cl in zip(names, clusters):
        if(name=="Gaussian Mixture"):
            labels = GaussianMixture(n_components=6).fit(X).predict(X)
        else:
            labels = cl.fit(X).labels_
        score = metrics.fowlkes_mallows_score(labels, y)
        print(name + ': ' + ('%.9f' % score).lstrip('0'))


if __name__ == '__main__':
    main()